The program ise recursive function to look for the subdirectories of the group. 
The time and space complexity of the program is O(n) which is (depth * No. of users)