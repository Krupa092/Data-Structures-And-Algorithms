In huffman coding program heapq library is used. 
The time complexity is O(nlogn) because program uses if inside for loop and the space complexity is O(n). 