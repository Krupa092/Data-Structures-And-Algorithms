LRU Cache means Least Recently Used Cacche. 
In the program two class have been created. 
One to create node and another is for LRU_Cache to remove the least recently used elements or search memory. 
Becasuse of methods get and set in class Program uses time complexity O(1).
it uses two data structures, when consider worst case the space complexity is O(n) , which is O(capacity)
