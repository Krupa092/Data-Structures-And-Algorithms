If the proper path exists the it will look throgh all the items in the list directory using for loop.
It will check if the subdirectory exists and look for the .c extension.
SO the time and space complexity of the program is O(n) which is depth of program O(depth)