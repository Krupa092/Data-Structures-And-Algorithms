The Block chain used append function the time complexity is O(1), and the space complexity is O(n).
