Trienode Time and Space complexity is O(n) and for suffix the time and space complexity is O(n). 
Trie Time and Space complexity for inserting algorithm is O(n) and for prefix time complexity is O(n) and space complexity is O(1).

