The Time complexity is O(log(n)) because the "binary search" is used.
No exrea space is required so the Space complexity also is the O(1).

