
In the first Trie class there are three classes. 
RouterTrie Class: For insert algorithm time and space complecity is O(n) and for find algorithm time complexity is O(n) space complexity is O(1)

RouterTrieNode Class: Time and space complexity is O(1).

Router Class: Time complexity is O(n) and space complexity is O(1). 