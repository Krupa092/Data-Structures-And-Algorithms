The time and space complexity of the program is O(n). Because, the "while" loop has been used the in the function sort_012.
the list is divided in to three parts, input number is less than, greater than and equals to the middle point.
so, the itterations are also less, so the overall time complexity is O(n). 
The algorithm does not require any extra space so the space complexity is O(1).
