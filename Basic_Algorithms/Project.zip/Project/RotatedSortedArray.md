Binary search algorithm is used to search rotated array number after searching pivot point, from which the array is divided in to two parts.
and the algorithm will search for the numbwr in respective part of the array.
Time Complexity: O(log(n))
Space Complexity: O(1)