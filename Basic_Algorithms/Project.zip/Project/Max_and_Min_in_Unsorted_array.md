In this program it is asked to find smallest and largest number from an unsorted array. The lists in the program will store minimum and maximum numbers.
The itterations has been going through the list.
The time complexity is O(n) and the space complexity is O(1).