In this program i have used recursion.
The algorithm sorts the array using merge sort, which has O(log(n)) Time complexity. so the overall time complexity is O(log(n)).
The merge sort space complexity is O(n), the algorithm then uses rearrange function with the space complexity O(n). 
So the overall Space Complexity is O(n).
